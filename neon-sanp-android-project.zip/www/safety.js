/*
  safety.js — Global crash-prevention net for Neon Sanp
  --------------------------------------------------------
  This file must load FIRST (before ads.js and game.js).
  It catches any unexpected JavaScript error anywhere in the app —
  including ones inside async code, ad callbacks, or future bugs —
  and prevents the app from ever showing a blank/frozen/crashed screen.
*/
(function () {
  'use strict';

  var recoveryShown = false;

  function showRecoveryUI(reason) {
    try {
      console.error('Neon Sanp caught an error:', reason);
      if (recoveryShown) return; // don't stack multiple recovery screens
      var overlay = document.getElementById('gameover-overlay');
      var start = document.getElementById('start-overlay');
      // If the game screens exist and are usable, just quietly return to
      // the start screen instead of showing a scary error message.
      if (start) {
        recoveryShown = true;
        if (overlay) overlay.style.display = 'none';
        start.style.display = 'flex';
        setTimeout(function () { recoveryShown = false; }, 1500);
        return;
      }
    } catch (e) {
      // even the recovery handler failed — absolute last resort below
    }

    // Absolute last resort: DOM itself is broken. Rebuild a minimal safe screen.
    try {
      var app = document.getElementById('app') || document.body;
      app.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;' +
        'height:100%;color:#a8ff3e;font-family:monospace;text-align:center;padding:24px;">' +
        'Kuch ghalat ho gaya.<br><br>' +
        '<button onclick="location.reload()" style="background:#a8ff3e;color:#06120c;border:none;' +
        'padding:12px 24px;border-radius:6px;font-weight:bold;font-family:monospace;">DOBARA KHOLEIN</button>' +
        '</div>';
    } catch (finalError) {
      // nothing more we can do; at least we never threw an uncaught exception
    }
  }

  // Catch every synchronous JS error app-wide
  window.addEventListener('error', function (event) {
    showRecoveryUI(event.error || event.message);
    // Returning true prevents the default browser "uncaught error" behavior
    return true;
  });

  // Catch every unhandled Promise rejection (async/await failures,
  // e.g. an AdMob call that rejects) app-wide
  window.addEventListener('unhandledrejection', function (event) {
    showRecoveryUI(event.reason);
    event.preventDefault();
  });

  console.log('Neon Sanp safety net active.');
})();
