# Neon Sanp — Play Store Publish Guide

Ye poora Android project hai (Capacitor-based). Is folder mein:

- `www/` — Aapka game (HTML/CSS/JS) — crash-safe code, AdMob-ready
- `android/` — Android Studio project (icon already set)
- `assets/generated/` — App icon, feature graphic, aur 3 screenshots
- `assets/play-store-listing.md` — Naam, description, sab listing text (copy-paste ready)
- `assets/privacy-policy-template.html` — Privacy policy (AdMob ke liye zaroori)

---

## STEP 1 — Apne computer pe setup karein

Ye cheezein install karein (agar pehle se nahi hain):
1. **Node.js** — https://nodejs.org (LTS version)
2. **Android Studio** — https://developer.android.com/studio

Phir terminal mein is project folder ke andar:
```
npm install
npx cap sync android
```

## STEP 2 — Android Studio mein kholein

1. Android Studio kholein → "Open" → is project ke andar `android` folder select karein
2. Gradle sync khud-ba-khud ho jayega (pehli baar thoda time lagega)
3. Top mein ek emulator ya apna phone (USB debugging ON kar ke) select karein
4. Green "Run" button dabayein — game aapke phone/emulator pe chalni chahiye

**Agar koi error aaye:** Zyada tar "Gradle sync failed" errors internet slow hone ki wajah se hote hain — dobara "Sync Project with Gradle Files" dabayein.

## STEP 3 — AdMob real IDs lagayein (zaroori — publish se pehle)

Abhi `www/ads.js` file mein Google ke TEST ad IDs lagi hain (safe hain, testing ke liye). Publish karne se pehle:

1. https://admob.google.com pe account banayein
2. "Apps" → "Add App" → Android select karein → apni app add karein
3. Aapko ek **App ID** milega — isse `android/app/src/main/AndroidManifest.xml` mein daalein (jahan `com.google.android.gms.ads.APPLICATION_ID` likha hai)
4. Do **Ad Units** banayein: ek Interstitial, ek Banner
5. In dono ka Ad Unit ID copy kar ke `www/ads.js` file ke `AD_UNITS` object mein daalein (jahan comment likha hai)
6. `npx cap sync android` dobara chalayein taake changes apply ho jayein

**IMPORTANT:** Jab tak AdMob approve na kare (naye account ko 24-48 ghante lag sakte hain), test IDs hi use karein — real IDs se pehle live ads dikhane se account suspend ho sakta hai.

## STEP 4 — Signed Release Build banayein

Play Store sirf "signed" build accept karta hai:

1. Android Studio mein: **Build → Generate Signed Bundle / APK**
2. **Android App Bundle (.aab)** select karein (Play Store ab yehi mangta hai)
3. "Create new..." se apni keystore banayein (password yaad rakhein — future updates ke liye same keystore chahiye hogi, is file ko safe backup rakhein!)
4. Build complete hone ke baad `.aab` file `android/app/release/` mein milegi

## STEP 5 — Play Console pe publish karein

Aapke pas pehle se Play Console account hai, to:

1. "Create app" → naam "Neon Sanp" daalein (ya `assets/play-store-listing.md` se copy karein)
2. **Store listing** mein `assets/play-store-listing.md` se short/full description copy-paste karein
3. **Graphics** section mein `assets/generated/` ki saari images upload karein:
   - `icon_master_512.png` → App icon
   - `feature_graphic_1024x500.png` → Feature graphic
   - `screenshot_1_title.png`, `screenshot_2_gameplay.png`, `screenshot_3_gameover.png` → Screenshots
4. **Privacy Policy URL** — `privacy-policy-template.html` ko GitHub Pages (free) ya kisi bhi hosting pe daal kar uska link yahan daalein (apna email bhi file mein edit kar lein)
5. **Content rating** questionnaire fill karein (Everyone/3+ honi chahiye)
6. **App content** → Ads section mein "Yes, my app contains ads" select karein
7. **Release → Production** mein jaa kar apni signed `.aab` file upload karein
8. Submit karein — Google review mein 1-3 din lagte hain

---

## Crash-safety notes (aapne pucha tha ke app band na ho)

- Har game function try/catch mein wrapped hai
- Agar AdMob ad load na ho (no internet, etc.) to game bilkul normal chalta rahega — sirf ad skip ho jayega
- App background mein jaye to game apne aap pause ho jata hai (state corrupt nahi hoti)
- Agar startup mein hi koi unexpected error aaye to blank/crashed screen ki bajaye ek friendly message dikhega

Isse Play Console ka "crash rate" kam rehta hai jo aapki app ranking ke liye zaroori hai.
