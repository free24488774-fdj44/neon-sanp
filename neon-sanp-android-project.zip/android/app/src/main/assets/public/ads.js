/*
  ads.js — AdMob integration for Neon Sanp
  --------------------------------------------------
  IMPORTANT: The IDs below are GOOGLE'S OFFICIAL TEST AD UNIT IDs.
  Test ads are safe to use while building/testing — they always show,
  never earn real money, and never risk your AdMob account.

  BEFORE PUBLISHING TO PLAY STORE:
  1. Create an AdMob account at admob.google.com
  2. Register this app in AdMob to get a real "App ID"
  3. Create ad units (Interstitial + Banner) to get real Ad Unit IDs
  4. Replace the TEST IDs below with YOUR real IDs
  5. Also update the App ID in android/app/src/main/AndroidManifest.xml

  Every AdMob call is wrapped in try/catch so that if ads fail to load
  (no internet, AdMob servers down, etc.) the GAME NEVER CRASHES —
  it just plays without an ad that round.
*/

var AdManager = (function () {
  var isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  var admob = null;
  var initialized = false;
  var interstitialReady = false;

  // Google's official TEST ad unit IDs (replace with real ones before publishing)
  var AD_UNITS = {
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    banner: 'ca-app-pub-3940256099942544/6300978111'
  };

  function safeGetAdmobPlugin() {
    try {
      if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob) {
        return window.Capacitor.Plugins.AdMob;
      }
    } catch (e) {
      console.warn('AdMob plugin not available:', e);
    }
    return null;
  }

  async function init() {
    if (!isNative) {
      console.log('AdManager: running in browser, ads disabled.');
      return;
    }
    try {
      admob = safeGetAdmobPlugin();
      if (!admob) return;
      await admob.initialize({
        requestTrackingAuthorization: true,
        testingDevices: [],
        initializeForTesting: false
      });
      initialized = true;
      await loadBanner();
      await preloadInterstitial();
    } catch (e) {
      console.warn('AdManager init failed (non-fatal):', e);
    }
  }

  async function loadBanner() {
    if (!initialized || !admob) return;
    try {
      var BannerAdPosition = window.CapacitorAdMob ? window.CapacitorAdMob.BannerAdPosition : 'BOTTOM_CENTER';
      var BannerAdSize = window.CapacitorAdMob ? window.CapacitorAdMob.BannerAdSize : 'ADAPTIVE_BANNER';
      await admob.showBanner({
        adId: AD_UNITS.banner,
        adSize: BannerAdSize,
        position: BannerAdPosition,
        margin: 0,
        isTesting: false
      });
    } catch (e) {
      console.warn('Banner ad failed to load (non-fatal):', e);
    }
  }

  async function preloadInterstitial() {
    if (!initialized || !admob) return;
    try {
      await admob.prepareInterstitial({
        adId: AD_UNITS.interstitial,
        isTesting: false
      });
      interstitialReady = true;
    } catch (e) {
      interstitialReady = false;
      console.warn('Interstitial preload failed (non-fatal):', e);
    }
  }

  async function showInterstitialOnGameOver() {
    if (!isNative || !initialized || !admob || !interstitialReady) return;
    try {
      await admob.showInterstitial();
      interstitialReady = false;
      // preload the next one for the following game-over
      preloadInterstitial();
    } catch (e) {
      console.warn('Interstitial show failed (non-fatal):', e);
    }
  }

  return {
    init: init,
    showInterstitialOnGameOver: showInterstitialOnGameOver
  };
})();

document.addEventListener('DOMContentLoaded', function () {
  try {
    AdManager.init();
  } catch (e) {
    console.warn('AdManager failed to start (non-fatal):', e);
  }
});
