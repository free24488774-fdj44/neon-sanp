/*
  game.js — Neon Sanp core game logic
  Wrapped defensively so a single bad frame or missing element never
  crashes the whole app (important for Play Store stability ratings).
*/
(function () {
  'use strict';

  try {
    var canvas = document.getElementById('board');
    var ctx = canvas.getContext('2d');
    var gridSize = 18;
    var tileCount = canvas.width / gridSize;

    var snake, dx, dy, food, score, best, gameRunning, speed, loopHandle;
    best = 0;

    function resetGame() {
      snake = [{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }];
      dx = 1; dy = 0;
      score = 0;
      speed = 130;
      placeFood();
      updateHud();
    }

    function placeFood() {
      var valid = false;
      var fx, fy, attempts = 0;
      while (!valid && attempts < 500) {
        fx = Math.floor(Math.random() * tileCount);
        fy = Math.floor(Math.random() * tileCount);
        valid = !snake.some(function (s) { return s.x === fx && s.y === fy; });
        attempts++;
      }
      food = { x: fx, y: fy };
    }

    function updateHud() {
      var scoreEl = document.getElementById('score');
      var bestEl = document.getElementById('best');
      if (scoreEl) scoreEl.textContent = score;
      if (bestEl) bestEl.textContent = best;
    }

    function drawCell(x, y, color, glow) {
      ctx.fillStyle = color;
      if (glow) {
        ctx.shadowColor = color;
        ctx.shadowBlur = 10;
      } else {
        ctx.shadowBlur = 0;
      }
      ctx.fillRect(x * gridSize + 1, y * gridSize + 1, gridSize - 2, gridSize - 2);
      ctx.shadowBlur = 0;
    }

    function draw() {
      ctx.fillStyle = '#0b1f14';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      drawCell(food.x, food.y, '#ffcf6e', true);
      snake.forEach(function (seg, i) {
        drawCell(seg.x, seg.y, i === 0 ? '#c6ff7a' : '#7dd63e', i === 0);
      });
    }

    function update() {
      var head = { x: snake[0].x + dx, y: snake[0].y + dy };

      if (head.x < 0 || head.x >= tileCount || head.y < 0 || head.y >= tileCount) {
        return endGame();
      }
      if (snake.some(function (s) { return s.x === head.x && s.y === head.y; })) {
        return endGame();
      }

      snake.unshift(head);

      if (head.x === food.x && head.y === food.y) {
        score += 10;
        if (score > best) best = score;
        updateHud();
        placeFood();
        if (speed > 60) speed -= 3;
      } else {
        snake.pop();
      }

      draw();
    }

    function gameLoop() {
      if (!gameRunning) return;
      try {
        update();
      } catch (e) {
        console.warn('Game loop error, ending game safely:', e);
        endGame();
        return;
      }
      loopHandle = setTimeout(gameLoop, speed);
    }

    function endGame() {
      gameRunning = false;
      clearTimeout(loopHandle);
      var finalText = document.getElementById('final-score-text');
      if (finalText) finalText.textContent = 'Aap ka score: ' + score + ' | Best: ' + best;
      var overlay = document.getElementById('gameover-overlay');
      if (overlay) overlay.style.display = 'flex';

      try {
        if (window.AdManager && typeof window.AdManager.showInterstitialOnGameOver === 'function') {
          window.AdManager.showInterstitialOnGameOver();
        }
      } catch (e) {
        console.warn('Ad call failed (non-fatal):', e);
      }
    }

    function startGame() {
      var startOverlay = document.getElementById('start-overlay');
      var overOverlay = document.getElementById('gameover-overlay');
      if (startOverlay) startOverlay.style.display = 'none';
      if (overOverlay) overOverlay.style.display = 'none';
      resetGame();
      draw();
      gameRunning = true;
      clearTimeout(loopHandle);
      loopHandle = setTimeout(gameLoop, speed);
    }

    function pauseGame() {
      gameRunning = false;
      clearTimeout(loopHandle);
    }

    function setDirection(nx, ny) {
      if (nx === -dx && ny === -dy) return;
      if (nx === dx && ny === dy) return;
      dx = nx; dy = ny;
    }

    document.addEventListener('keydown', function (e) {
      if (!gameRunning) return;
      switch (e.key) {
        case 'ArrowUp': setDirection(0, -1); break;
        case 'ArrowDown': setDirection(0, 1); break;
        case 'ArrowLeft': setDirection(-1, 0); break;
        case 'ArrowRight': setDirection(1, 0); break;
      }
    });

    function bindButton(id, nx, ny) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('click', function () { setDirection(nx, ny); });
    }
    bindButton('up', 0, -1);
    bindButton('down', 0, 1);
    bindButton('left', -1, 0);
    bindButton('right', 1, 0);

    var touchStartX = 0, touchStartY = 0;
    canvas.addEventListener('touchstart', function (e) {
      var t = e.changedTouches[0];
      touchStartX = t.clientX;
      touchStartY = t.clientY;
    }, { passive: true });

    canvas.addEventListener('touchend', function (e) {
      var t = e.changedTouches[0];
      var diffX = t.clientX - touchStartX;
      var diffY = t.clientY - touchStartY;
      if (Math.abs(diffX) > Math.abs(diffY)) {
        if (Math.abs(diffX) > 20) setDirection(diffX > 0 ? 1 : -1, 0);
      } else {
        if (Math.abs(diffY) > 20) setDirection(0, diffY > 0 ? 1 : -1);
      }
    }, { passive: true });

    var startBtn = document.getElementById('start-btn');
    var restartBtn = document.getElementById('restart-btn');
    if (startBtn) startBtn.addEventListener('click', startGame);
    if (restartBtn) restartBtn.addEventListener('click', startGame);

    // Pause the game loop when the app goes to background (saves battery,
    // avoids state bugs) — works both in browser tabs and native Android.
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) pauseGame();
    });

    try {
      if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
        window.Capacitor.Plugins.App.addListener('appStateChange', function (state) {
          if (!state.isActive) pauseGame();
        });
      }
    } catch (e) {
      console.warn('App lifecycle listener not available (non-fatal):', e);
    }

    resetGame();
    draw();
  } catch (fatalError) {
    // Absolute last-resort safety net: if anything above throws during
    // startup, show a friendly message instead of a blank/crashed screen.
    console.error('Neon Sanp failed to start:', fatalError);
    var appEl = document.getElementById('app');
    if (appEl) {
      appEl.innerHTML = '<div style="color:#a8ff3e;text-align:center;padding:30px;font-family:monospace;">' +
        'Kuch ghalat ho gaya.<br>Please app dobara kholein.</div>';
    }
  }
})();
