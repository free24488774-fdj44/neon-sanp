package com.neonstudio.neonsanp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
