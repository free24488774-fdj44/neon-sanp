# Play Store Listing — Neon Sanp

## App Name (30 chars max)
Neon Sanp: Snake Game

## Short Description (80 chars max)
Classic Snake game with a glowing neon twist. Simple, addictive, offline!

## Full Description (4000 chars max)

🐍 NEON SANP — the classic Snake game, reimagined with a glowing neon look!

Guide your snake through a dark arena, eat the glowing food, and grow as long
as you can — without hitting the walls or your own tail. Simple to learn,
hard to master, and perfect for a quick break.

✨ FEATURES
• Smooth, responsive controls — swipe or use on-screen arrows
• Glowing neon visuals with a satisfying arcade feel
• Increasing speed as you grow — test your reflexes
• Score & best score tracking
• Lightweight — works great even on low-end phones
• No sign-up, no internet required to play
• Completely free to play

🎮 HOW TO PLAY
Swipe up, down, left, or right (or use the on-screen buttons) to steer your
snake toward the glowing food. Every bite makes you longer — and the game
faster. Avoid the walls and don't run into yourself. How high can you score?

Perfect for a quick 2-minute break or a longer high-score chase. Simple
one-thumb gameplay, made for everyone.

Download Neon Sanp now and see how long your snake can grow! 🟢

## Category
Games > Arcade

## Content Rating
Everyone / 3+ (no violence, no objectionable content)

## Tags / Keywords
snake game, arcade, classic snake, neon, offline game, casual game, retro game

## Privacy Policy
NOTE: You MUST host a privacy policy at a public URL before publishing,
because this app shows ads (AdMob collects some device/ad data).
See the "privacy-policy-template.html" file — upload it anywhere public
(GitHub Pages is free) and put that URL in Play Console.

## Contact Email
(add your email here — required by Play Console)

## Graphics Checklist (already generated in assets/generated/)
- [x] App icon (512x512): icon_master_512.png
- [x] Feature graphic (1024x500): feature_graphic_1024x500.png
- [x] Screenshot 1 (1080x1920): screenshot_1_title.png
- [x] Screenshot 2 (1080x1920): screenshot_2_gameplay.png
- [x] Screenshot 3 (1080x1920): screenshot_3_gameover.png
  (Play Store requires minimum 2 screenshots — you have 3, ready to upload)
