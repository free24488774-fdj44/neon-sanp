from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os, math, random

OUT = "/home/claude/snake-app/assets/generated"
os.makedirs(OUT, exist_ok=True)

# Theme colors
BG_DARK = (6, 18, 12)
BG_PANEL = (11, 31, 20)
NEON = (168, 255, 62)
NEON_HEAD = (198, 255, 122)
NEON_BODY = (125, 214, 62)
AMBER = (255, 207, 110)
TEXT_LIGHT = (216, 245, 200)

def font(size, bold=True):
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

def glow_ellipse(draw_img, box, color, blur=18, alpha=160):
    glow = Image.new("RGBA", draw_img.size, (0,0,0,0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse(box, fill=color + (alpha,))
    glow = glow.filter(ImageFilter.GaussianBlur(blur))
    return glow

def glow_rounded_rect(size_img, box, color, radius=20, blur=18, alpha=170):
    glow = Image.new("RGBA", size_img, (0,0,0,0))
    gd = ImageDraw.Draw(glow)
    gd.rounded_rectangle(box, radius=radius, fill=color + (alpha,))
    glow = glow.filter(ImageFilter.GaussianBlur(blur))
    return glow

def draw_snake_glyph(img, cx, cy, scale=1.0, head_color=NEON_HEAD, body_color=NEON_BODY, glow=True):
    """Draw a coiled snake made of rounded blocks, matching in-game look."""
    draw = ImageDraw.Draw(img, "RGBA")
    cell = int(30 * scale)
    gap = int(4 * scale)
    # snake path (grid coords) forming a coil / S shape
    path = [(0,0),(1,0),(2,0),(3,0),(3,1),(3,2),(2,2),(1,2),(0,2),(0,3),(0,4),(1,4),(2,4),(3,4)]
    path = path[::-1]  # head at the end (front)
    n = len(path)
    for i, (gx, gy) in enumerate(path):
        x0 = cx + gx * (cell + gap) - (3.5*(cell+gap))/2
        y0 = cy + gy * (cell + gap) - (4*(cell+gap))/2
        x1 = x0 + cell
        y1 = y0 + cell
        is_head = (i == n - 1)
        color = head_color if is_head else body_color
        if glow:
            g = glow_rounded_rect(img.size, (x0-4, y0-4, x1+4, y1+4), color, radius=int(cell*0.35), blur=10, alpha=110)
            img.alpha_composite(g)
        draw.rounded_rectangle((x0, y0, x1, y1), radius=int(cell*0.3), fill=color + (255,))
    # eyes on head
    head_gx, head_gy = path[-1]
    hx = cx + head_gx * (cell + gap) - (3.5*(cell+gap))/2
    hy = cy + head_gy * (cell + gap) - (4*(cell+gap))/2
    eye_r = max(2, int(cell*0.09))
    draw.ellipse((hx+cell*0.25-eye_r, hy+cell*0.3-eye_r, hx+cell*0.25+eye_r, hy+cell*0.3+eye_r), fill=(6,18,12,255))
    draw.ellipse((hx+cell*0.65-eye_r, hy+cell*0.3-eye_r, hx+cell*0.65+eye_r, hy+cell*0.3+eye_r), fill=(6,18,12,255))

def rounded_bg(size, radius, color):
    img = Image.new("RGBA", size, (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0,0,size[0],size[1]), radius=radius, fill=color+(255,))
    return img

# ---------------------------------------------------------------
# 1. APP ICON (512x512, master) — will be resized for all densities
# ---------------------------------------------------------------
def make_icon():
    S = 512
    img = rounded_bg((S,S), int(S*0.22), BG_DARK)
    d = ImageDraw.Draw(img, "RGBA")
    # subtle inner panel
    d.rounded_rectangle((18,18,S-18,S-18), radius=int(S*0.19), outline=NEON+(90,), width=4)
    # big glow behind snake
    g = glow_rounded_rect((S,S), (S*0.18,S*0.18,S*0.82,S*0.82), NEON, radius=60, blur=40, alpha=90)
    img.alpha_composite(g)
    draw_snake_glyph(img, S/2, S/2*1.02, scale=1.55)
    # amber food dot accent
    fd = ImageDraw.Draw(img, "RGBA")
    fx, fy, fr = S*0.78, S*0.24, S*0.045
    g2 = glow_ellipse(img, (fx-fr-6, fy-fr-6, fx+fr+6, fy+fr+6), AMBER, blur=10, alpha=180)
    img.alpha_composite(g2)
    fd.ellipse((fx-fr, fy-fr, fx+fr, fy+fr), fill=AMBER+(255,))
    img.convert("RGB").save(f"{OUT}/icon_master_512.png")
    img.save(f"{OUT}/icon_master_512_rgba.png")
    return img

# ---------------------------------------------------------------
# 2. FEATURE GRAPHIC (1024x500) — Play Store header banner
# ---------------------------------------------------------------
def make_feature_graphic():
    W,H = 1024,500
    img = Image.new("RGBA", (W,H), BG_DARK+(255,))
    d = ImageDraw.Draw(img, "RGBA")
    # background grid texture
    for x in range(0, W, 28):
        d.line((x,0,x,H), fill=(255,255,255,6))
    for y in range(0, H, 28):
        d.line((0,y,W,y), fill=(255,255,255,6))
    # big ambient glow left
    g = glow_ellipse(img, (-150,-100,450,600), NEON, blur=90, alpha=70)
    img.alpha_composite(g)
    draw_snake_glyph(img, 230, 250, scale=2.2)
    # Title text
    f_title = font(76, bold=True)
    f_sub = font(28, bold=False)
    title = "NEON SANP"
    tb = d.textbbox((0,0), title, font=f_title)
    tw, th = tb[2]-tb[0], tb[3]-tb[1]
    tx, ty = 470, H/2 - th - 10
    # glow text (draw multiple times blurred)
    glow_txt = Image.new("RGBA", (W,H), (0,0,0,0))
    gd = ImageDraw.Draw(glow_txt)
    gd.text((tx,ty), title, font=f_title, fill=NEON+(200,))
    glow_txt = glow_txt.filter(ImageFilter.GaussianBlur(6))
    img.alpha_composite(glow_txt)
    d.text((tx,ty), title, font=f_title, fill=NEON+(255,))
    d.text((tx+4, ty+th+18), "Classic Snake • Reimagined", font=f_sub, fill=TEXT_LIGHT+(255,))
    img.convert("RGB").save(f"{OUT}/feature_graphic_1024x500.png")

# ---------------------------------------------------------------
# Screenshot helpers
# ---------------------------------------------------------------
def phone_canvas():
    W,H = 1080,1920
    img = Image.new("RGBA", (W,H), BG_DARK+(255,))
    d = ImageDraw.Draw(img, "RGBA")
    for x in range(0, W, 40):
        d.line((x,0,x,H), fill=(255,255,255,5))
    for y in range(0, H, 40):
        d.line((0,y,W,y), fill=(255,255,255,5))
    return img, d

def draw_board(img, d, top, size=920, score_val=0):
    left = (1080-size)//2
    box = (left, top, left+size, top+size)
    # glow border
    g = glow_rounded_rect(img.size, box, NEON, radius=28, blur=25, alpha=120)
    img.alpha_composite(g)
    d.rounded_rectangle(box, radius=28, outline=NEON+(255,), width=6, fill=BG_PANEL+(255,))
    # grid inside board
    cell = size // 18
    random.seed(score_val + 1)
    # draw a snake path across the board
    segs = []
    x,y = 4,9
    segs.append((x,y))
    dirs = [(1,0)]*5 + [(0,-1)]*3 + [(1,0)]*4 + [(0,1)]*2 + [(1,0)]*3
    for dxn,dyn in dirs:
        x += dxn; y += dyn
        x = max(0,min(17,x)); y = max(0,min(17,y))
        segs.append((x,y))
    for i,(gx,gy) in enumerate(segs):
        cx0 = left + gx*cell + 4
        cy0 = top + gy*cell + 4
        cx1 = cx0 + cell - 8
        cy1 = cy0 + cell - 8
        color = NEON_HEAD if i == len(segs)-1 else NEON_BODY
        d.rounded_rectangle((cx0,cy0,cx1,cy1), radius=8, fill=color+(255,))
    # food
    fgx, fgy = 13, 4
    fx0 = left + fgx*cell + 4; fy0 = top + fgy*cell + 4
    fx1 = fx0+cell-8; fy1 = fy0+cell-8
    fg = glow_rounded_rect(img.size, (fx0-4,fy0-4,fx1+4,fy1+4), AMBER, radius=10, blur=14, alpha=170)
    img.alpha_composite(fg)
    d.rounded_rectangle((fx0,fy0,fx1,fy1), radius=8, fill=AMBER+(255,))
    return box

def title_block(img, d, y=140):
    f_title = font(72, bold=True)
    title = "NEON SANP"
    tb = d.textbbox((0,0), title, font=f_title)
    tw = tb[2]-tb[0]
    tx = (1080-tw)//2
    glow_txt = Image.new("RGBA", img.size, (0,0,0,0))
    gd = ImageDraw.Draw(glow_txt)
    gd.text((tx,y), title, font=f_title, fill=NEON+(200,))
    glow_txt = glow_txt.filter(ImageFilter.GaussianBlur(8))
    img.alpha_composite(glow_txt)
    d.text((tx,y), title, font=f_title, fill=NEON+(255,))

def hud_block(img, d, y, score_val, best_val):
    f = font(38, bold=True)
    left_txt = f"SCORE: {score_val}"
    right_txt = f"BEST: {best_val}"
    d.text((90, y), left_txt, font=f, fill=AMBER+(255,))
    tb = d.textbbox((0,0), right_txt, font=f)
    d.text((1080-90-(tb[2]-tb[0]), y), right_txt, font=f, fill=AMBER+(255,))

def rounded_button(img, d, cx, cy, text, w=460, h=110):
    box = (cx-w//2, cy-h//2, cx+w//2, cy+h//2)
    g = glow_rounded_rect(img.size, box, NEON, radius=22, blur=20, alpha=130)
    img.alpha_composite(g)
    d.rounded_rectangle(box, radius=22, fill=NEON+(255,))
    f = font(38, bold=True)
    tb = d.textbbox((0,0), text, font=f)
    tw, th = tb[2]-tb[0], tb[3]-tb[1]
    d.text((cx-tw/2, cy-th/2-8), text, font=f, fill=BG_DARK+(255,))

# ---------------------------------------------------------------
# 3. SCREENSHOT 1 — Title / Start screen
# ---------------------------------------------------------------
def make_screenshot_title():
    img, d = phone_canvas()
    title_block(img, d, y=520)
    f = font(34, bold=False)
    lines = ["Sanp ko khilao aur bara karo.", "Deewar ya khud se takra na jaye."]
    y = 700
    for line in lines:
        tb = d.textbbox((0,0), line, font=f)
        tw = tb[2]-tb[0]
        d.text(((1080-tw)//2, y), line, font=f, fill=TEXT_LIGHT+(255,))
        y += 50
    draw_snake_glyph(img, 540, 1180, scale=2.6)
    rounded_button(img, d, 540, 1650, "SHURU KAREIN")
    img.convert("RGB").save(f"{OUT}/screenshot_1_title.png")

# ---------------------------------------------------------------
# 4. SCREENSHOT 2 — Gameplay
# ---------------------------------------------------------------
def make_screenshot_gameplay():
    img, d = phone_canvas()
    title_block(img, d, y=70)
    hud_block(img, d, 230, 90, 140)
    draw_board(img, d, top=310, size=920, score_val=90)
    img.convert("RGB").save(f"{OUT}/screenshot_2_gameplay.png")

# ---------------------------------------------------------------
# 5. SCREENSHOT 3 — Game Over
# ---------------------------------------------------------------
def make_screenshot_gameover():
    img, d = phone_canvas()
    title_block(img, d, y=70)
    hud_block(img, d, 230, 60, 140)
    box = draw_board(img, d, top=310, size=920, score_val=60)
    # dark overlay panel
    ov = Image.new("RGBA", img.size, (0,0,0,0))
    od = ImageDraw.Draw(ov)
    od.rectangle((0,0,1080,1920), fill=(6,18,12,225))
    img.alpha_composite(ov)
    d = ImageDraw.Draw(img, "RGBA")
    f_go = font(64, bold=True)
    go_txt = "GAME OVER"
    tb = d.textbbox((0,0), go_txt, font=f_go)
    tw = tb[2]-tb[0]
    glow_txt = Image.new("RGBA", img.size, (0,0,0,0))
    gd = ImageDraw.Draw(glow_txt)
    gd.text(((1080-tw)//2, 760), go_txt, font=f_go, fill=NEON+(200,))
    glow_txt = glow_txt.filter(ImageFilter.GaussianBlur(8))
    img.alpha_composite(glow_txt)
    d = ImageDraw.Draw(img, "RGBA")
    d.text(((1080-tw)//2, 760), go_txt, font=f_go, fill=NEON+(255,))
    f_score = font(38, bold=False)
    sc_txt = "Aap ka score: 60 | Best: 140"
    tb2 = d.textbbox((0,0), sc_txt, font=f_score)
    d.text(((1080-(tb2[2]-tb2[0]))//2, 870), sc_txt, font=f_score, fill=TEXT_LIGHT+(255,))
    rounded_button(img, d, 540, 1020, "DOBARA KHELEIN")
    img.convert("RGB").save(f"{OUT}/screenshot_3_gameover.png")

if __name__ == "__main__":
    make_icon()
    make_feature_graphic()
    make_screenshot_title()
    make_screenshot_gameplay()
    make_screenshot_gameover()
    print("done")
