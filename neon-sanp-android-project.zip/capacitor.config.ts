import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.neonstudio.neonsanp',
  appName: 'Neon Sanp',
  webDir: 'www'
};

export default config;
